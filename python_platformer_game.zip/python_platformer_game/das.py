import random

kaiden = random.randint(0, 10)
kaidenl = random.randint(0, 10)

if kaiden > kaidenl:
    kaiden = True
    kaidenl = False
if kaiden < kaidenl:
    kaiden = False
    kaidenl = True

loud = True

if kaiden is loud:
    print(random.choice('be quite!\nplee-he-hez\nkaiden your so loud!'.splitlines()))
if kaiden is not loud:
    print(random.choice('finaly\nthank you\nomg finaly'.splitlines()))
