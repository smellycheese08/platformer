import pygame

# Set up pygame
pygame.init()
screen = pygame.display.set_mode((640, 480))

# Set up power-up
powerup_image = pygame.Surface((32, 32))
powerup_image.fill((255, 0, 0))
powerup_rect = powerup_image.get_rect()
powerup_active = True

# Set up timer event

POWERUP_TIMER = pygame.USEREVENT + 1
pygame.time.set_timer(POWERUP_TIMER, 5000)
# Main game loop
while True:
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
        elif event.type == POWERUP_TIMER:
            powerup_active = False

    screen.fill((255, 255, 255))
    if powerup_active:
        screen.blit(powerup_image, powerup_rect)
    pygame.display.flip()
