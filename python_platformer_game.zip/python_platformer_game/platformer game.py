import random
import pygame
import sys
from os import listdir
from os.path import isfile, join
pygame.init()

pygame.display.set_caption("platformer")

# change the width / height of the window (I know I misspelled height)
WIDTH, HIGHT = 1174, 667
# set the fps
FPS = 60
# set the player speed
PLAYER_VEL = 5
RES_PLAYER_VEL = PLAYER_VEL
# change how many jumps you have / jump hieght
max_jumps = 2
res_max_jumps = max_jumps
jump_hieght = 8
res_jump_hieght = jump_hieght
# set how mutch health the player starts with
max_health = 200
res_max_health = max_health
current_health = max_health

game_over = False
paused = False
fade_counter = 0
heals = 0

game_over_sfx_count = 0
game_over_sfx = pygame.mixer.Sound('sound effects/Game over sfx.mp3')
eat_sound_sfx = pygame.mixer.Sound('sound effects/eat sound sfx.mp3')
jump_sfx = pygame.mixer.Sound('sound effects/Jump sound sfx.mp3')
hurt_sfx = pygame.mixer.Sound('sound effects/hurt sound sfx.mp3')

PINEAPPLE_POWERUP_TIMER = pygame.USEREVENT + 9
CHERRIES_POWERUP_TIMER = pygame.USEREVENT + 10
ORANGE_POWERUP_TIMER = pygame.USEREVENT + 11
BANANA_POWERUP_TIMER = pygame.USEREVENT + 12
MELON_POWERUP_TIMER = pygame.USEREVENT + 13

red = (255, 0, 0)
green = (0, 255, 0)
yellow = (255, 255, 0)
white = (255, 255, 255)
black = (0, 0, 0)
grey = (130, 130, 130)
h_p_t_color = (green)
e_h_p_t_color = (green)

window = pygame.display.set_mode((WIDTH, HIGHT))
clock = pygame.time.Clock()

rd_bg = random.choice("sky bg.jpg\neve sky bg.jpg\ntree sky bg.jpg\nred stary sky bg.jpg".splitlines())
BG = pygame.image.load('assets/Background/' + rd_bg)


def get_font(size):
    return pygame.font.Font("assets/font.ttf", size)


def character_sel():
    while True:
        OPTIONS_MOUSE_POS = pygame.mouse.get_pos()

        window.fill("white")

        OPTIONS_TEXT = get_font(45).render("This is the", True, black)
        OPTIONS_TEXT2 = get_font(45).render("CHARACTER SELECT screen.", True, black)
        OPTIONS_RECT = OPTIONS_TEXT.get_rect(center=(WIDTH/2, 260))
        OPTIONS_RECT2 = OPTIONS_TEXT2.get_rect(center=(WIDTH/2, 330))
        window.blit(OPTIONS_TEXT, OPTIONS_RECT)
        window.blit(OPTIONS_TEXT2, OPTIONS_RECT2)

        OPTIONS_BACK = Button(image=pygame.image.load('assets/Menu/Buttons/red rect.jpg'), pos=(WIDTH/2, 460),
                              text_input='<', font=get_font(75), base_color=black, hovering_color=white)

        OPTIONS_BACK.changeColor(OPTIONS_MOUSE_POS)
        OPTIONS_BACK.update(window)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if OPTIONS_BACK.checkForInput(OPTIONS_MOUSE_POS):
                    main_menu()

        pygame.display.update()


def main_menu():
    while True:
        window.blit(BG, (0, 0))

        MENU_MOUSE_POS = pygame.mouse.get_pos()

        MENU_TEXT = get_font(100).render("MAIN MENU", True, grey)
        MENU_RECT = MENU_TEXT.get_rect(center=(WIDTH/2, 100))

        PLAY_BUTTON = Button(image=None, pos=(WIDTH/2, 250),
                             text_input="PLAY", font=get_font(75), base_color=black, hovering_color=white)
        OPTIONS_BUTTON = Button(image=None, pos=(WIDTH/2, 400),
                                text_input="CHARACTER-SEL", font=get_font(75), base_color=black, hovering_color=white)
        QUIT_BUTTON = Button(image=None, pos=(WIDTH/2, 550),
                             text_input="QUIT", font=get_font(75), base_color=black, hovering_color=white)

        window.blit(MENU_TEXT, MENU_RECT)

        for button in [PLAY_BUTTON, OPTIONS_BUTTON, QUIT_BUTTON]:
            button.changeColor(MENU_MOUSE_POS)
            button.update(window)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.MOUSEBUTTONDOWN:
                if PLAY_BUTTON.checkForInput(MENU_MOUSE_POS):
                    if __name__ == "__main__":
                        main(window)
                        pygame.display.update()
                if OPTIONS_BUTTON.checkForInput(MENU_MOUSE_POS):
                    character_sel()
                if QUIT_BUTTON.checkForInput(MENU_MOUSE_POS):
                    pygame.quit()
                    sys.exit()

        pygame.display.update()


def flip(sprites):
    return[pygame.transform.flip(sprite, True, False) for sprite in sprites]


def load_sprite_sheets(dir1, dir2, width, hight, directon=False):
    path = join('assets', dir1, dir2)
    images = [f for f in listdir(path) if isfile(join(path, f))]

    all_sprites = {}

    for image in images:
        sprite_sheet = pygame.image.load(join(path, image)).convert_alpha()

        sprites = []
        for i in range(sprite_sheet.get_width() // width):
            surface = pygame.Surface((width, hight), pygame.SRCALPHA, 32)
            rect = pygame.Rect(i * width, 0, width, hight)
            surface.blit(sprite_sheet, (0, 0), rect)
            sprites.append(pygame.transform.scale2x(surface))

        if directon:
            all_sprites[image.replace('.png', '') + '_right'] = sprites
            all_sprites[image.replace('.png', '') + '_left'] = flip(sprites)
        else:
            all_sprites[image.replace('.png', '')] = sprites

    return all_sprites


def get_block(size):
    path = join('assets', 'Terrain', 'Terrain.png')
    image = pygame.image.load(path).convert_alpha()
    surface = pygame.Surface((size, size), pygame.SRCALPHA, 32)
    rect = pygame.Rect(96, 0, size, size)
    surface.blit(image, (0, 0,), rect)
    return pygame.transform.scale2x(surface)


class Player(pygame.sprite.Sprite):
    COLOR = (255, 0, 0)
    GRAVITY = 1     # set witch player sprite you want \/
    sprites = load_sprite_sheets('MainCharacters', 'MaskDude', 32, 32, True)
#   set how fast player animations are
#                     \/
    ANIMATION_DELAY = 5

    def __init__(self, x, y, width, hight):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, hight)
        self.x_vel = 0
        self.y_vel = 0
        self.mask = None
        self.direction = 'left'
        self.animation_count = 1
        self.fall_count = 0
        self.jump_count = 0
        self.hit = False
        self.hit_count = 0

    def jump(self):
        self.y_vel = -self.GRAVITY * jump_hieght
        self.animation_count = 0
        self.jump_count += 1
        if self.jump_count == 1:
            self.fall_count = 0

    def move(self, dx, dy):
        self.rect.x += dx
        self.rect.y += dy

    def make_hit(self, ammount):
        self.hit = True
        self.hit_count = 0
        global current_health
        current_health -= ammount

    def move_left(self, vel):
        self.x_vel = - vel
        if self.direction != 'left':
            self.direction = 'left'
            self.annotation_count = 0

    def move_right(self, vel):
        self.x_vel = vel
        if self.direction != 'right':
            self.direction = 'right'
            self.annotation_count = 0

    def loop(self, fps):
        self.y_vel += min(1, (self.fall_count / fps) * self.GRAVITY)
        self.move(self.x_vel, self. y_vel)
        if self.hit:
            self.hit_count += 1
#                set how long the hit state lasts
#                                 \/
        if self.hit_count > fps * 1.5:
            self.hit = False
            self.hit_count = 0

        self.fall_count += 1
        self.update_sprite()

    def landed(self):
        self.fall_count = 0
        self.y_vel = 0
        self.jump_count = 0

    def hit_head(self):
        self.count = 0
        self.y_vel *= -1

    def update_sprite(self):
        sprite_sheet = 'idle'
        if self.hit:
            sprite_sheet = 'hit'
            global current_health
            current_health -= .3
        elif self.y_vel < 0:
            if self.jump_count == 1:
                sprite_sheet = 'jump'
            elif self.jump_count >= 1:
                sprite_sheet = 'double_jump'
        elif self.y_vel > self.GRAVITY:
            sprite_sheet = 'fall'
        elif self.x_vel != 0:
            sprite_sheet = 'run'

        sprite_sheet_name = sprite_sheet + '_' + self.direction
        sprites = self.sprites[sprite_sheet_name]
        sprite_index = (self.animation_count // self.ANIMATION_DELAY) % len(sprites)
        self.sprite = sprites[sprite_index]
        self.animation_count += 1
        self.update()

    def update(self):
        self.rect = self.sprite.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.sprite)

    def draw(self, win, offset_x):
        win.blit(self.sprite, (self.rect.x - offset_x, self.rect.y))


class Button():
	def __init__(self, image, pos, text_input, font, base_color, hovering_color):
		self.image = image
		self.x_pos = pos[0]
		self.y_pos = pos[1]
		self.font = font
		self.base_color, self.hovering_color = base_color, hovering_color
		self.text_input = text_input
		self.text = self.font.render(self.text_input, True, self.base_color)
		if self.image is None:
			self.image = self.text
		self.rect = self.image.get_rect(center=(self.x_pos, self.y_pos))
		self.text_rect = self.text.get_rect(center=(self.x_pos, self.y_pos))

	def update(self, screen):
		if self.image is not None:
			screen.blit(self.image, self.rect)
		screen.blit(self.text, self.text_rect)

	def checkForInput(self, position):
		if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
			return True
		return False

	def changeColor(self, position):
		if position[0] in range(self.rect.left, self.rect.right) and position[1] in range(self.rect.top, self.rect.bottom):
			self.text = self.font.render(self.text_input, True, self.hovering_color)
		else:
			self.text = self.font.render(self.text_input, True, self.base_color)


class object(pygame.sprite.Sprite):
    def __init__(self, x, y, width, hight, name=None):
        super().__init__()
        self.rect = pygame.Rect(x, y, width, hight)
        self.image = pygame.Surface((width, hight), pygame.SRCALPHA)
        self.width = width
        self.hight = hight
        self.name = name

    def draw(self, win, offset_x):
        win.blit(self.image, (self.rect.x - offset_x, self.rect.y))


class Block(object):
    def __init__(self, x, y, size):
        super().__init__(x, y, size, size)
        block = get_block(size)
        self.image.blit(block, (0, 0))
        self.mask = pygame.mask.from_surface(self.image)


class Fire(object):
    ANIMATION_DELAY = 3

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'fire')
        self.fire = load_sprite_sheets('Traps', 'Fire', width, hight)
        self.image = self.fire['off'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'off'

    def on(self):
        self.animation_name = 'on'

    def off(self):
        self.animation_name = 'off'

    def loop(self):
        sprites = self.fire[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)

        if self.animation_count // self.ANIMATION_DELAY > len(sprites):
            self.animation_count = 0


class Spikes(object):
    ANIMATION_DELAY = 3

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Spikes')
        self.spikes = load_sprite_sheets('Traps', 'Spikes', width, hight)
        self.image = self.spikes['Idle'][0]
        self.animation_name = 'Idle'

    def idle(self):
        self.animation_name = 'Idle'


class Health_power_up(object):
    ANIMATION_DELAY = 3

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'hp_power_up')
        self.hp_power_up = load_sprite_sheets('Traps', 'hp power up', width, hight)
        self.image = self.hp_power_up['Hit (18x18)'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Hit (18x18)'

    def loop(self, player, object):
        if pygame.sprite.collide_mask(player, self):
            POWERUP_TIMER = pygame.USEREVENT + 1
            pygame.time.set_timer(POWERUP_TIMER, 15000)
            global heals
            if self in object and heals < 10:
                object.remove(self)
                heals += 1


class Slime_enemy(object):
    ANIMATION_DELAY = 5
    enemy_current_health = 70
    enemy_max_health = enemy_current_health
    slime_enemy_move = 1
    global e_h_p_t_color

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'slime-attack')
        self.Slime = load_sprite_sheets('Items', 'enemies', width, hight)
        self.image = self.Slime['slime-Sheet half'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'slime-Sheet half'

    def loop(self, player, lef_cords, rit_cords):
        sprites = self.Slime[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        if pygame.sprite.collide_mask(player, self):
            global current_health
            current_health -= 20

        self.rect.x += Slime_enemy.slime_enemy_move
        if self.rect.x >= lef_cords:
            Slime_enemy.slime_enemy_move *= -1
        if self.rect.x <= rit_cords:
            Slime_enemy.slime_enemy_move *= -1


class Bat_enemy(object):
    ANIMATION_DELAY = 5
    enemy_current_health = 100
    enemy_max_health = enemy_current_health
    global e_h_p_t_color
    bat_enemy_move = 2

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Bat_Fly')
        self.Bat = load_sprite_sheets('Items', 'enemies', width, hight)
        self.image = self.Bat['Bat_Fly'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Bat_Fly'
        self.x = x
        self.y = y

    def loop(self, player, lef_cords, rit_cords):
        sprites = self.Bat[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)

        self.rect.x += Bat_enemy.bat_enemy_move
        if self.rect.x <= lef_cords:
            self.animation_name = 'Bat_Fly'
            Bat_enemy.bat_enemy_move *= -1
        if self.rect.x >= rit_cords:
            self.animation_name = 'Bat_Fly left'
            Bat_enemy.bat_enemy_move *= -1

        if pygame.sprite.collide_mask(player, self):
            global current_health
            current_health -= 20


class Pineapple(object):
    ANIMATION_DELAY = 5
    power_up_count = 0
    global PLAYER_VEL

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'pineapple')
        self.Pineapple = load_sprite_sheets('Items', 'Fruits', width, hight)
        self.image = self.Pineapple['Pineapple'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Pineapple'

    def loop(self, player, object):
        sprites = self.Pineapple[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        if Pineapple.power_up_count <= 0 and pygame.sprite.collide_mask(player, self):
            global PLAYER_VEL
            if self in object:
                PLAYER_VEL += 5
                Pineapple.power_up_count += 1
                eat_sound_sfx.play()
                object.remove(self)
                pygame.time.set_timer(PINEAPPLE_POWERUP_TIMER, random.randint(10000, 17000))


class Cherries(object):
    ANIMATION_DELAY = 5
    power_up_count = 0

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Cherries')
        self.Cherries = load_sprite_sheets('Items', 'Fruits', width, hight)
        self.image = self.Cherries['Cherries'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Cherries'

    def loop(self, player, object):
        sprites = self.Cherries[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        if Cherries.power_up_count <= 0 and pygame.sprite.collide_mask(player, self):
            global max_health
            if self in object:
                max_health *= 2
                Cherries.power_up_count += 1
                eat_sound_sfx.play()
                object.remove(self)
                pygame.time.set_timer(CHERRIES_POWERUP_TIMER, random.randint(10000, 17000))


class Orange(object):
    ANIMATION_DELAY = 5
    power_up_count = 0

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Orange')
        self.Orange = load_sprite_sheets('Items', 'Fruits', width, hight)
        self.image = self.Orange['Orange'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Orange'

    def loop(self, player, object):
        sprites = self.Orange[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        if Orange.power_up_count <= 0 and pygame.sprite.collide_mask(player, self):
            global jump_hieght
            if self in object:
                jump_hieght += 7
                Orange.power_up_count += 1
                eat_sound_sfx.play()
                object.remove(self)
                pygame.time.set_timer(ORANGE_POWERUP_TIMER, random.randint(10000, 17000))


class Banana(object):
    ANIMATION_DELAY = 5
    power_up_count = 0

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Banana')
        self.Banana = load_sprite_sheets('Items', 'Fruits', width, hight)
        self.image = self.Banana['Bananas'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Bananas'

    def loop(self, player, object):
        sprites = self.Banana[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        if Banana.power_up_count <= 0 and pygame.sprite.collide_mask(player, self):
            global max_jumps
            if self in object:
                max_jumps += 1
                Banana.power_up_count += 1
                eat_sound_sfx.play()
                object.remove(self)
                pygame.time.set_timer(BANANA_POWERUP_TIMER, random.randint(10000, 17000))


class Melon(object):
    ANIMATION_DELAY = 5
    power_up_count = 0

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Melon')
        self.Melon = load_sprite_sheets('Items', 'Fruits', width, hight)
        self.image = self.Melon['Melon'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Melon'

    def loop(self, player, object):
        sprites = self.Melon[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        if Melon.power_up_count <= 0 and pygame.sprite.collide_mask(player, self):
            global FPS
            global jump_hieght
            global PLAYER_VEL
            if self in object:
                FPS = 24
                jump_hieght += 3
                PLAYER_VEL += 5
                Melon.power_up_count += 1
                eat_sound_sfx.play()
                object.remove(self)
                pygame.time.set_timer(MELON_POWERUP_TIMER, random.randint(10000, 17000))


class Apple(object):
    ANIMATION_DELAY = 5

    def __init__(self, x, y, width, hight):
        super().__init__(x, y, width, hight, 'Apple')
        self.Apple = load_sprite_sheets('Items', 'Fruits', width, hight)
        self.image = self.Apple['Apple'][0]
        self.mask = pygame.mask.from_surface(self.image)
        self.animation_count = 0
        self.animation_name = 'Apple'

    def loop(self, player, object):
        sprites = self.Apple[self.animation_name]
        sprite_index = (self.animation_count
                        // self.ANIMATION_DELAY) % len(sprites)
        self.image = sprites[sprite_index]
        self.animation_count += 1
        self.rect = self.image.get_rect(topleft=(self.rect.x, self.rect.y))
        self.mask = pygame.mask.from_surface(self.image)
        global current_health
        if pygame.sprite.collide_mask(player, self):
            if self in object:
                current_health += 45
                eat_sound_sfx.play()
                object.remove(self)


class HUD():

    global current_health
    global max_health
    global heals
    global h_p_t_color

    def heal_power(heals):
        heal_power_text = get_font(20).render(f"REMAINING HEALS: {heals}", True, black)
        heal_power_rect = heal_power_text.get_rect(center=(900, 77))
        window.blit(heal_power_text, heal_power_rect)

    def health_bar(h_p_t_color):
        if max_health >= 2000:
            pygame.draw.rect(window, white, (90, 67, max_health/4+18, 15))
            pygame.draw.rect(window, black, (100, 70, max_health/4, 10))
            pygame.draw.rect(window, green, (100, 70, current_health/4, 10))
            if current_health <= max_health / 2:
                pygame.draw.rect(window, yellow, (100, 70, current_health/4, 10))
                h_p_t_color = (yellow)
            if current_health <= max_health / 3.5:
                pygame.draw.rect(window, red, (100, 70, current_health/4, 10))
                h_p_t_color = (red)
            heal_power_text = get_font(10).render(f'{int(current_health)}', True, h_p_t_color)
            heal_power_rect = heal_power_text.get_rect(center=(115, 60))
            window.blit(heal_power_text, heal_power_rect)
        elif max_health >= 1000 and max_health < 2000:
            pygame.draw.rect(window, white, (90, 67, max_health/3+18, 15))
            pygame.draw.rect(window, black, (100, 70, max_health/3, 10))
            pygame.draw.rect(window, green, (100, 70, current_health/3, 10))
            if current_health <= max_health / 2:
                pygame.draw.rect(window, yellow, (100, 70, current_health/3, 10))
                h_p_t_color = (yellow)
            if current_health <= max_health / 3.5:
                pygame.draw.rect(window, red, (100, 70, current_health/3, 10))
                h_p_t_color = (red)
            heal_power_text = get_font(10).render(f'{int(current_health)}', True, h_p_t_color)
            heal_power_rect = heal_power_text.get_rect(center=(115, 60))
            window.blit(heal_power_text, heal_power_rect)
        elif max_health >= 500 and max_health < 1000:
            pygame.draw.rect(window, white, (90, 67, max_health/2+18, 15))
            pygame.draw.rect(window, black, (100, 70, max_health/2, 10))
            pygame.draw.rect(window, green, (100, 70, current_health/2, 10))
            if current_health <= max_health / 2:
                pygame.draw.rect(window, yellow, (100, 70, current_health/2, 10))
                h_p_t_color = (yellow)
            if current_health <= max_health / 3.5:
                pygame.draw.rect(window, red, (100, 70, current_health/2, 10))
                h_p_t_color = (red)
            heal_power_text = get_font(10).render(f'{int(current_health)}', True, h_p_t_color)
            heal_power_rect = heal_power_text.get_rect(center=(115, 60))
            window.blit(heal_power_text, heal_power_rect)
        elif max_health < 500:
            pygame.draw.rect(window, white, (90, 67, max_health+18, 15))
            pygame.draw.rect(window, black, (100, 70, max_health, 10))
            pygame.draw.rect(window, green, (100, 70, current_health, 10))
            if current_health <= max_health / 2:
                pygame.draw.rect(window, yellow, (100, 70, current_health, 10))
                h_p_t_color = (yellow)
            if current_health <= max_health / 3.5:
                pygame.draw.rect(window, red, (100, 70, current_health, 10))
                h_p_t_color = (red)
            heal_power_text = get_font(10).render(f'{int(current_health)}', True, h_p_t_color)
            heal_power_rect = heal_power_text.get_rect(center=(115, 60))
            window.blit(heal_power_text, heal_power_rect)

    def Pause():
        mouse_pos = pygame.mouse.get_pos()

        pause_var = Button(image=None, pos=(60, 120),
                           text_input="", font=get_font(15), base_color=white, hovering_color=green)

        pause_var.changeColor(pygame.mouse.get_pos())
        pause_var.update(window)

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            global paused
            if event.type == pygame.MOUSEBUTTONDOWN:
                if pause_var.checkForInput(mouse_pos):
                    paused = True

        pygame.display.update()


def get_background(name):
    image = pygame.image.load(join('assets', 'Background', name))
    _, _, width, hight = image.get_rect()
    tiles = []

    for i in range(WIDTH // width):
        for j in range(HIGHT // hight):
            pos = (i * width, j * hight)
            tiles.append(pos)

    return tiles, image


def draw(window, background, bg_image, player, objects, offset_x):
    for tile in background:
        window.blit(bg_image, tile)

    for obj in objects:
        obj.draw(window, offset_x)

        if current_health <= 0:
            game_over_screen()

    HUD.health_bar(h_p_t_color)
    HUD.heal_power(heals)

    player.draw(window, offset_x)

    pygame.display.update()


def handle_vertical_collision(player, objects, dy):
    collided_objects = []
    for obj in objects:
        if pygame.sprite.collide_mask(player, obj):
            if dy > 0:
                player.rect.bottom = obj.rect.top
                player.landed()
            elif dy < 0:
                player.rect.top = obj.rect.bottom
                player.hit_head()


            collided_objects.append(obj)

    return collided_objects


def collide(player, objects, dx):
    player.move(dx, 0)
    player.update()
    collided_object = None
    for obj in objects:
        if pygame.sprite.collide_mask(player, obj):
            collided_object = obj
            break

    player.move(-dx, 0)
    player.update()
    return collided_object


def handle_move(player, objects):
    keys = pygame.key.get_pressed()
    global heals

    player.x_vel = 0
    collide_left = collide(player, objects, -PLAYER_VEL * 2)
    collide_right = collide(player, objects, PLAYER_VEL * 2)

    if keys[pygame.K_a] and not collide_left or keys[pygame.K_LEFT] and not collide_left:
        player.move_left(PLAYER_VEL)
    if keys[pygame.K_d] and not collide_right or keys[pygame.K_RIGHT] and not collide_right:
        player.move_right(PLAYER_VEL)

    vertical_colide = handle_vertical_collision(player, objects, player.y_vel)
    to_check = [collide_left, collide_right, *vertical_colide]
    for obj in to_check:
    #        enable traps acctions
    #                 \/
    #  \--------------------------------/
        if obj and obj.name == 'fire':
            player.make_hit(ammount=.2)
            hurt_sfx.play()
        if obj and obj.name == 'Spikes':
            player.make_hit(ammount=20)
            hurt_sfx.play()
        if obj and obj.name == 'slime-attack':
            player.make_hit(ammount=.05)
            hurt_sfx.play()
        if obj and obj.name == 'Bat_Fly':
            player.make_hit(ammount=.05)
            hurt_sfx.play()
    #  /--------------------------------\

    pygame.display.update()


def Pause_screen():
    global paused
    global current_health
    global heals
    global game_over
    global PLAYER_VEL
    global fade_counter
    global jump_hieght, res_jump_hieght
    global game_over_sfx_count
    global FPS
    mouse_pos = pygame.mouse.get_pos()

    paused_text = get_font(100).render("PAUSED", True, grey)
    paused_rect = paused_text.get_rect(center=(WIDTH/2, 150))
    window.blit(paused_text, paused_rect)

    PAUSE_BACK_2_MENU = Button(image=None, pos=(WIDTH/2, 320),
                               text_input="BACK-TO-MENU", font=get_font(75), base_color=black, hovering_color=white)

    PAUSE_BACK_2_MENU.changeColor(pygame.mouse.get_pos())
    PAUSE_BACK_2_MENU.update(window)

    PAUSE_RESUME = Button(image=None, pos=(WIDTH/2, 450),
                          text_input="RESUME", font=get_font(75), base_color=black, hovering_color=white)

    PAUSE_RESUME.changeColor(pygame.mouse.get_pos())
    PAUSE_RESUME.update(window)

    PAUSE_QUIT = Button(image=None, pos=(WIDTH/2, 580),
                        text_input="QUIT", font=get_font(75), base_color=black, hovering_color=white)

    PAUSE_QUIT.changeColor(pygame.mouse.get_pos())
    PAUSE_QUIT.update(window)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if PAUSE_BACK_2_MENU.checkForInput(mouse_pos):
                current_health = max_health
                heals = 0
                fade_counter = 0
                game_over = False
                PLAYER_VEL = RES_PLAYER_VEL
                jump_hieght = res_jump_hieght
                game_over_sfx_count = 0
                paused = False
                FPS = 60
                rd_bg
                main_menu()
            if PAUSE_QUIT.checkForInput(mouse_pos):
                pygame.quit()
                sys.exit()
            if PAUSE_RESUME.checkForInput(mouse_pos):
                paused = False

    pygame.display.update()


def game_over_screen():
    global current_health
    global heals
    global game_over
    global PLAYER_VEL
    global fade_counter
    global jump_hieght, res_jump_hieght
    global game_over_sfx_count
    mouse_pos = pygame.mouse.get_pos()

    if fade_counter < WIDTH:
        fade_counter += 9
        for y in range(0, 6, 2):
            pygame.draw.rect(window, black, (0, y * 120, fade_counter, 120.166))
            pygame.draw.rect(window, black, (WIDTH - fade_counter, (y + 1) * 120, WIDTH, 120.16))

    game_over_text = get_font(100).render("GAME OVER", True, red)
    game_over_rect = game_over_text.get_rect(center=(WIDTH/2, 150))
    window.blit(game_over_text, game_over_rect)

    GAME_OVER_RESTART = Button(image=None, pos=(WIDTH/2, 340),
                               text_input="RESTART", font=get_font(75), base_color=white, hovering_color=green)

    GAME_OVER_RESTART.changeColor(pygame.mouse.get_pos())
    GAME_OVER_RESTART.update(window)

    GAME_OVER_QUIT = Button(image=None, pos=(WIDTH/2, 460),
                            text_input="QUIT", font=get_font(75), base_color=white, hovering_color=green)

    GAME_OVER_QUIT.changeColor(pygame.mouse.get_pos())
    GAME_OVER_QUIT.update(window)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()
        if event.type == pygame.MOUSEBUTTONDOWN:
            if GAME_OVER_RESTART.checkForInput(mouse_pos):
                current_health = max_health
                heals = 0
                fade_counter = 0
                game_over = False
                PLAYER_VEL = RES_PLAYER_VEL
                jump_hieght = res_jump_hieght
                game_over_sfx_count = 0
                main_menu()
            if GAME_OVER_QUIT.checkForInput(mouse_pos):
                pygame.quit()
                sys.exit()

    pygame.display.update()


def main(window):
    global current_health
    global max_health
    global heals
    global PLAYER_VEL
    global max_jumps
    global jump_hieght
    global game_over
    global paused
    global FPS
    global res_max_health

    clock = pygame.time.Clock()
    backgruond, bg_image = get_background(rd_bg)

    block_size = 96

    player = Player(900, HIGHT-100, 50, 50)

#   set more traps, enemies, or power ups
#  \----------------------------------------------------------------------------------------/
#   power ups
    health_power_up1 = Health_power_up(-160, HIGHT - block_size - 550, 16, 32)
    health_power_up2 = Health_power_up(130, HIGHT - block_size - 550, 16, 32)

    speed_pineapple1 = Pineapple(690, HIGHT - block_size - 140, 32, 32)

    jump_Orange1 = Orange(160, HIGHT - block_size - 130, 32, 32)
    jump_Orange2 = Orange(-230, HIGHT - block_size - 130, 32, 32)
    jump_Orange3 = Orange(1100, HIGHT - block_size - 45, 32, 32)

    jump_banana1 = Banana(200, HIGHT - block_size - 45, 32, 32)

    slow_time_Melon1 = Melon(1500, HIGHT - block_size - 240, 32, 32)

    heal_apple1 = Apple(400, HIGHT - block_size - 325, 32, 32)
    heal_apple2 = Apple(-465,  HIGHT - block_size - 325, 32, 32)

    healthx2_Cherries = Cherries(500, HIGHT - block_size - 45, 32, 32)

#   enemies
    slime_enemy = Slime_enemy(1450, HIGHT - block_size - 240, 32, 28)

    bat_enemy = Bat_enemy(-475, HIGHT - 96 - 400, 64, 64)
#   traps
    fier1 = Fire(-15, HIGHT - block_size - 304, 16, 32)

    fier2 = Fire(2000, HIGHT - block_size - 64, 16, 32)
    fier1.on()
    fier2.on()
#  /--------------------------------------------------------------------------------------\

#   add the repeating stuff here
#  \---------------------------------------------------------------------------------------------------------/
    floor1 = [Block(i * block_size, HIGHT - block_size, block_size)
              for i in range(-WIDTH // block_size, (WIDTH) // block_size)]

    floor2 = [Block(i * block_size + block_size * 27, HIGHT - block_size - block_size * 2, block_size)
              for i in range(-WIDTH // block_size, (WIDTH + block_size * -20) // block_size)]

    floor3 = [Block(i * block_size + block_size * 35, HIGHT - block_size - block_size * 2, block_size)
              for i in range(-WIDTH // block_size, (WIDTH + block_size * -21) // block_size)]

    spikes1 = [Spikes(i * 32 + block_size * -2, HIGHT - 32 - block_size * 1, 16, 32)
               for i in range(-WIDTH // block_size, (WIDTH + block_size * 15) // block_size)]
#  /---------------------------------------------------------------------------------------------------------\

#            add blocks, traps, or power ups to objects
#           \-----------------------------------------------------------/
    object = [*floor1, *floor2, *floor3, *spikes1,
              Block(block_size * -7, HIGHT - block_size * 2, block_size),
              Block(block_size * -5, HIGHT - block_size * 4, block_size),
              Block(block_size * -2, HIGHT - block_size * 6, block_size),
              Block(block_size * 1, HIGHT - block_size * 6, block_size),
              Block(block_size * 4, HIGHT - block_size * 4, block_size),
              Block(block_size * 7, HIGHT - block_size * 2, block_size),
              Block(block_size * -0.5, HIGHT - block_size * 3.5, block_size),
              fier1, fier2, slime_enemy, bat_enemy, health_power_up1,
              health_power_up2, speed_pineapple1, jump_Orange1, jump_Orange2,
              jump_Orange3, jump_banana1, heal_apple1, heal_apple2,
              healthx2_Cherries, slow_time_Melon1]
#           /-----------------------------------------------------------\

    offset_x = 0
#   change the scroling animation
#                       \/
    scroll_area_width = 550

    runing = True
    while runing:
        clock.tick(FPS)

        if game_over is False and paused is False:
            if current_health > max_health:
                current_health = max_health

            HUD.heal_power(heals)

            player.loop(FPS)

    #           add the trap, power up, or enemy loops here
    #                                \/
    #      \---------------------------------------------------------/
    #       traps
            fier1.loop()
            fier2.loop()
    #       enemies
            slime_enemy.loop(player, 1345, 1760)

            bat_enemy.loop(player, -530, 400)
    #       power ups
            health_power_up1.loop(player, object)
            health_power_up2.loop(player, object)

            speed_pineapple1.loop(player, object)

            jump_Orange1.loop(player, object)
            jump_Orange2.loop(player, object)
            jump_Orange3.loop(player, object)

            jump_banana1.loop(player, object)

            heal_apple1.loop(player, object)
            heal_apple2.loop(player, object)

            slow_time_Melon1.loop(player, object)

            healthx2_Cherries.loop(player, object)
    #      /---------------------------------------------------------\

            handle_move(player, object)

            draw(window, backgruond, bg_image, player, object, offset_x)

            if ((player.rect.right - offset_x >= WIDTH - scroll_area_width) and
                player.x_vel > 0) or (
                    (player.rect.left - offset_x <= scroll_area_width) and
                    player.x_vel < 0):
                offset_x += player.x_vel

            if player.rect.top > HIGHT or current_health <= 0:
                game_over = True

        elif game_over is True:
            PLAYER_VEL = RES_PLAYER_VEL
            jump_hieght = res_jump_hieght
            max_jumps = res_max_jumps
            FPS = 60
            max_health = res_max_health
            Pineapple.power_up_count = 0
            Cherries.power_up_count = 0
            Orange.power_up_count = 0
            Banana.power_up_count = 0
            Melon.power_up_count = 0
            global game_over_sfx_count, game_over_sfx
            if game_over_sfx_count <= 0:
                game_over_sfx_count += 1
                game_over_sfx.play()
            game_over_screen()

        elif paused is True:
            Pause_screen()

        if current_health <= 0:
            current_health = 0

        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                runing = False
                break

            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_SPACE and player.jump_count < max_jumps:
                    global jump_sfx
                    jump_sfx.play()
                    player.jump()
                if event.key == pygame.K_UP and heals > 0:
                    current_health += 50
                    heals -= 1
                if event.key == pygame.K_q and heals < 10:
                    heals += 1
                if event.key == pygame.K_ESCAPE:
                    paused = True
                    HUD.Pause()
                if event.key == pygame.K_DOWN:
                    bat_enemy.enemy_current_health -= 20

            if event.type == PINEAPPLE_POWERUP_TIMER:
                PLAYER_VEL = RES_PLAYER_VEL
                Pineapple.power_up_count = 0
            if event.type == CHERRIES_POWERUP_TIMER:
                max_health = res_max_health
                Cherries.power_up_count = 0
            if event.type == BANANA_POWERUP_TIMER:
                max_jumps = res_max_jumps
                Banana.power_up_count = 0
            if event.type == ORANGE_POWERUP_TIMER:
                jump_hieght = res_jump_hieght
                Orange.power_up_count = 0
            if event.type == MELON_POWERUP_TIMER:
                FPS = 60
                jump_hieght = res_jump_hieght
                PLAYER_VEL = RES_PLAYER_VEL
                Melon.power_up_count = 0

    pygame.quit()
    quit()


main_menu()
